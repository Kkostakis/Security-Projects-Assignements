#!/bin/bash
# 5th security project created by Kkostakis
# Digital Certificates-Signatures

# Make Directory if it is does not exists
sudo mkdir -p /etc/pki/tls/certs/
# Change to the working Directory
sudo cd /etc/pki/tls/certs
# Print a message on screen to ask user about FQDN
echo -e "Enter your virtual host FQDN: \n"
# Read FQDN user's input
read cert
# Generate Private key
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out $cert.key
# Protect the key by setting the right permission
chmod 600 $cert.key
# Generate certificate signing request
openssl req -new -key $cert.key -out $cert.csr
# Generate SSL certificate 
openssl x509 -req -days 365 -in $cert.csr -signkey $cert.key -out $cert.crt
# Print message to the user on screen
echo -e " The Certificate and Key for $cert has been generated!\nDo not forget to add it to your webserver configuration!"
ls -all /etc/pki/tls/certs/
echo `pwd`

# Check the validity of the certificate
# First check the order of our certificate
openssl crl2pkcs7 -nocrl -certfile $cert.crt | openssl pkcs7 -print_certs -noout

# Make sure that we have matching private key and main/server certificate
openssl x509 -noout -modulus -in $cert.crt | openssl md5
openssl rsa -noout -modulus -in $cert.key | openssl md5

# Then ensure that the date of the certificate is also right
openssl x509 -noout -in $cert.crt -dates

# Creation of intermediate certificate, root certificate and chain-certificate file
cd /root/ca
# Create private key for root certificate
openssl genrsa -aes256 -out ca_root.key 4096
# Create root certificate for a long amount of time(7305 days)
openssl req -config ca_root.cnf \
            -key ca_root.key \
            -new -x509 -days 7305 -sha256 -extensions v3_ca \
            -out ca_root.crt
# Usually, a CA root certificate is trusted, so there is no need to create a signing request.
# Verification of the root certificate
openssl x509 -noout -text -in ca_root.crt

# Create private key for intermediate CA certificate
openssl genrsa -aes256 -out ca_intermediate.key 4096

# Request signing process for intermediate certificate
openssl req -config /root/ca/intermediate/ca_intermediate.cnf \
            -new -sha256 \
            -key ca_intermediate.key \
            -out ca_intermediate.csr

# Sign the intermediate CA certificate
openssl x509 -req -in ca_intermediate.csr -CA ca_root.crt -CAkey ca_root.key -CAcreateserial -out ca_intermediate.crt -days 365 -sha256

# Print the certificate
openssl x509 -noout -text -in ca_intermediate.crt

# Create chain_certificate.crt
cat ca_root.crt ca_intermediate.crt > chain_certificate.crt

# Last but not least, check the validity of the certificate chain(in case the message shows ok, then the certificate is valid!!!)
openssl verify -CAfile server.crt $cert.crt chain_certificate.crt
openssl x509 -noout -text -in $cert.crt
