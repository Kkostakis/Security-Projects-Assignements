#!/bin/bash
# 11th Exercise of cyber security

file=$1

cryptograph()
{

  echo -n "User please enter your choice:"
  read choice

  while [ $choice -ne 1 ] && [ $choice -ne 2 ] && [ $choice -ne 3 ];
  do
    echo -n "User please enter your choice:"
    read choice
  done

  if [ $choice -eq 1 ]
  then
      echo -n "Encryption of file $file with aes(counter mode)!!!"
      openssl enc -aes-128-ctr -in $file -out [$file].bin -K 0123456789abcdef0123456789abcdef -iv 00000000000000000000000000000000

  elif [ $choice -eq 2 ]
  then
      echo -n "Encryption of file $file with RC4!!!"
      openssl enc -rc4 -in $file -out [$file].enc -K 0123456789abcdef0123456789abcdef

  elif [ $choice -eq 3 ]
  then
      echo -n "Decryption of file $file with RC4(1), or CTR(2)!!!"
      read ch

      while [ $ch -ne 1 ] && [ $ch -ne 2 ];
      do
         echo -n "User please enter your choice:"
         read ch
      done

      if [ $ch -eq 1 ]
      then
          echo -n "Decrypt the encrypted file $file with rc4"
          openssl enc -d -rc4 -in $file -out [$file].out -K 0123456789abcdef0123456789abcdef

      elif [ $ch -eq 2 ]
      then
          echo -n "Decrypt the encrypted file $file with AES counter mode"
          openssl enc -d -aes-128-ctr -in $file -out [$file].out -K 0123456789abcdef0123456789abcdef -iv 00000000000000000000000000000000
      fi
  fi

}

cryptograph file
