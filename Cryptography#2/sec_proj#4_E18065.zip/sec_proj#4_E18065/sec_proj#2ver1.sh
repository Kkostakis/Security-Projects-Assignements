#!/bin/bash
# 2nd Exercise of cyber security
# You can give greek characters as input!!!!

file=$1
file2=$2

cryptograph()
{

  echo -n "User please enter your choice:"
  read choice

  while [ $choice -ne 1 ] && [ $choice -ne 2 ] && [ $choice -ne 3 ] && [ $choice -ne 4 ];
  do
    echo -n "User please enter your choice:"
    read choice
  done

  if [ $choice -eq 1 ]
  then
      echo -n "Ecryption of file $file with openssl(cbc)!!!"
      openssl enc -aes-256-cbc -pbkdf2 -in $file -out [$file].enc

  elif [ $choice -eq 3 ]
  then
      echo -n "Ecryption of file $file with openssl(ecb)!!!"
      openssl enc -aes-256-ecb -pbkdf2 -in $file -out [$file].enc

  elif [ $choice -eq 4 ]
  then
      echo -n "Ecryption of file $file with openssl(counter mode)!!!"
      openssl enc -aes-128-ctr -in $file -out [$file].bin -K 0123456789abcdef0123456789abcdef -iv 00000000000000000000000000000000

  elif [ $choice -eq 2 ]
  then
      echo -n "Decryption of file $file with EBC(2), CBC(1) or CTR(3)!!!"
      read ch

      while [ $ch -ne 1 ] && [ $ch -ne 2 ] && [ $ch -ne 3 ];
      do
         echo -n "User please enter your choice:"
         read ch
      done

      if [ $ch -eq 1 ]
      then
          echo -n "Decrypt the encrypted file $file with cbc"
          openssl enc -aes-256-cbc -in $file2 -pbkdf2 -d -out [$file2].txt

      elif [ $ch -eq 2 ]
      then
          echo -n "Decrypt the encrypted file $file with ecb"
          openssl enc -aes-256-ecb -in $file2 -pbkdf2 -d -out [$file2].txt

      elif [ $ch -eq 3 ]
      then
          echo -n "Decrypt the encrypted file $file with ctr"
          openssl enc -d -aes-128-ctr -in $file2 -out [$file2].out -K 0123456789abcdef0123456789abcdef -iv 00000000000000000000000000000000
      fi
  fi

}

cryptograph file