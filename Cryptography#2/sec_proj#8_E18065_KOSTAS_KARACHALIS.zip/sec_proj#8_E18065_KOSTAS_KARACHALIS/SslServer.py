import http.server # Uses the library to create the first server(http type)
import ssl # Utilises the ssl(secure socket layer) protocol

print("Listening on port 3000...")

server_address = ('localhost', 3000) # The address of the https server that is going to be made via the ssl protocol
httpd = http.server.HTTPServer(server_address, http.server.SimpleHTTPRequestHandler) # Creates secure connection between our http server(which is created by this command and the https server_address)

# The newly created server utilises the self-signed certificate which is created by the command openssl req -new -x509 -keyout key.pem -out server.pem -days 365 -nodes
httpd.socket = ssl.wrap_socket(httpd.socket,
                               server_side=True,
                               certfile="server.pem",
                               keyfile="key.pem",
                               ssl_version=ssl.PROTOCOL_TLS)
httpd.serve_forever()
