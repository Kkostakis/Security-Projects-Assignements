#!/bin/bash
# This is the eighth project created by Kkostakis
# This command creates a self-signed(x509) certificate with private key and it exports ther certificate with name server.pem and the key.pem
echo "<<This is the self-signed certificate with private key key.pem encrypted with rsa!!!>>"
openssl req -new -x509 -keyout key.pem -out server.pem -days 365 -nodes
