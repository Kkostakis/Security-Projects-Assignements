import math
import sys

# Euclidean Algorithm(Not extended version) Implementation so as to find gcd(a,b)
def gcd_num(a,b):
    
    if (b == 0):
        return a;
    elif (a >= b & b > 0):
        return gcd_num(b, a%b);
    
    
num1 = input("User enter the first number:")

# Here, the conversion function int(...) is used due to the fact that with input("...") the user input becomes string type,
# whereas we need the type of the user input to be an integer, as the while function will not work, so as the gcd_num function 

# This is done in case the user enters a non-positive number
while (int(num1) < 0):
    num1 = input("User please enter the first number again:")
    
num2 = input("User enter the second number:")

 # This is done in case the user enters a non-positive number
while (int(num2) < 0):
    num2 = input("User please enter the second number again:")
    
euclidean = gcd_num(int(num1), int(num2)) 

# This is the result of the gcd from euclidean algorithm implementation!!!!    
print("The gcd of %d and %d from euclidean extended implementation is: %d!!!!\n" %(int(num1), int(num2), int(euclidean)))