import math
import sys

# Euclidean Algorithm(Extended version) Implementation so as to find gcd(a,b) through s and t
  
def gcd_num (num1, num2): 

# Here a set of variables is used in order to calculate the greatest common divisor with euclidean extended algorithm
# It is used this way so as to accurately return the correct result of the calculation

    if (num1 == 0):
        
        a1 = 0; 
        a2 = 1; 
        return num2, a1, a2; 
    else:
        result, f1, f2 = gcd_num(num2 % num1, num1); # The data set (tuple) 
        
        return result, f2 - (num2 // num1) * f1, f1; 
    # In the extended euclidean algorithm our goal is to calculate the bezout coefficients s,t so as to s×a + t×b = gcd(a,b)
    # We used the operator // in case the division of num1 and num2 returns a float number because it floors the number by removing the point past decimal 

num1 = input("User enter the first number:")

# Here, the conversion function int(...) is used due to the fact that with input("...") the user input becomes string type,
# whereas we need the type of the user input to be an integer, as the while function will not work, so as the gcd_num function
 
# This is done in case the user enters a non-positive number
while (int(num1) < 0):
    num1 = input("User please enter the first number again:")
    
num2 = input("User enter the second number:")

# This is done in case the user enters a non-positive number
while (int(num2) < 0):
    num2 = input("User please enter the second number again:")
   
f = 0; 
f = int(f); # This conversion is done because we need all the string to be formatted into integers later for the display

g = 0;
g = int(g); # This conversion is done because we need all the string to be formatted into integers later for the display

res, f, g = gcd_num(int(num1), int(num2)); 

# This is the result of the gcd from euclidean algorithm implementation!!!!    
print("The gcd of %d and %d from euclidean extended implementation is: %d with" %(int(num1), int(num2), int(res)))
print(f"s = {f}, t = {g}!!!!")
  