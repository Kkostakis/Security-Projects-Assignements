#!/bin/bash
# This is the 9th project created by Kkostakis

file=$1 # Takes tha original text(plain text) as the first argument
file2=$2 # Takes the encrypted text from the 1st option as the second argument

hashaes() # Function which contains the choice, namely whether the user launches the encryption/decryption of a file e.g.(somefile.txt)
{

  echo -n "User please enter your choice:"
  read choice

  while [ $choice -ne 1 ] && [ $choice -ne 2 ]; # The user can only enter the numbers (1 or 2)
  do
    echo -n "User please enter your choice:"
    read choice
  done

  if [ $choice -eq 1 ] # Encryption of file with hash-aes-256
  then
      echo -n "Encryption of file with hash encryption & aes-256 salt!!!!"
      openssl enc -aes-256-cbc -md sha256 -salt -pbkdf2 -in $file -out [$file].enc
  elif [ $choice -eq 2 ] # Decryption of encrypted file with hash-aes-256
  then
      echo -n "Decryption of the encrypted file and revertion to its original state!!!!"
      openssl enc -aes-256-cbc -d -md sha256 -salt  -pbkdf2 -in $file2 -out [$file2].txt
  fi

}

hashaes file

echo -n "This is the end of the algorithm, terminating process..."

