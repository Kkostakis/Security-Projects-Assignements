#include <stdio.h> // Library used for input and output functions
#include <string.h> // Library which contains functions for strings
 
int main()
{

    char plaintext[100]; // Table used for the plain text or message that the user wishes to encrypt and then decrypt via vigenere cipher
    char vigenerekey[100]; // Table used for the key in order for the vigenere encryption to work

    printf("User please enter the message(plain text):");
    scanf("%s", &plaintext);

    char alphabet[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; // String (table of characters) alphabet contains all letters only uppercase and ''

    // This loop is made to ensure that the user gives as message input only letters(Uppercase) and not numbers as the vigenere cipher is based on the letters of the alphabet
    // and vigenere uses letters as mapping to other letters in a matrix (vigenere matrix)!! 
    // The function used to achieve that is strpbrk and it is used to check if the user input has matching characters with another string (sequence of characters)

    do 
    {
        printf("User please enter the message(plain text) once more:");
        scanf("%s", &plaintext);
    }while(!strpbrk(plaintext, alphabet));
    
    
    printf("Generate the encryption key for vigenere:");
    scanf("%s", &vigenerekey);

     do 
    {
        printf("Generate the encryption key for vigenere:");
        scanf("%s", &vigenerekey);
    }while(!strpbrk(vigenerekey, alphabet));

    int length_of_text = strlen(plaintext); // Takes the length of the table of characters (or string)
    int length_of_key = strlen(vigenerekey); // Takes the length of the table of characters (or string)
    int i, j; // Indexes for the loops
 
    char new_key[length_of_text];
    char encryptedText[length_of_text];
    char decryptedText[length_of_text];
 
    // Generation of the new key for vigenere encryption & decryption
    for(i = 0, j = 0; i < length_of_text; ++i, ++j){
        if(j == length_of_key)
            j = 0;
 
        new_key[i] = vigenerekey[j];
    }
 
    new_key[i] = '\0';
 
    // Encryption sequence of the original text
    for(i = 0; i < length_of_text; ++i)
        encryptedText[i] = ((plaintext[i] + new_key[i]) % 26) + 'A';
 
    encryptedText[i] = '\0';
 
    // Decryption sequence of the encrypted text
    for(i = 0; i < length_of_text; ++i)
        decryptedText[i] = (((encryptedText[i] - new_key[i]) + 26) % 26) + 'A';
 
    decryptedText[i] = '\0';
 
    printf("The original message is: %s!!!!", plaintext);
    printf("\nThe key of vigenere cipher is: %s!!!!", vigenerekey);
    printf("\nThe new key that was generated is: %s!!!!", new_key);
    printf("\nThe encrypted version (via vigenere) of the original text is: %s!!!!", encryptedText);
    printf("\nThe decrypted text that was decoded from the vigenere encryption is: %s!!!!", decryptedText);
 
    return 0;
}