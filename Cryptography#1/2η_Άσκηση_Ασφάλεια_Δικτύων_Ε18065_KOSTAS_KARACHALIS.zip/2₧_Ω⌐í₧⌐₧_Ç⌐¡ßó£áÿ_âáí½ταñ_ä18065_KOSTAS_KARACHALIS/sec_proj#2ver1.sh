#!/bin/bash
# 2nd Exercise of cyber security

file=$1
file2=$2

cryptograph()
{

  echo -n "User please enter your choice:"
  read choice

  while [ $choice -ne 1 ] && [ $choice -ne 2 ] && [ $choice -ne 3 ];
  do
    echo -n "User please enter your choice:"
    read choice
  done

  if [ $choice -eq 1 ]
  then
      echo -n "Ecryption of file $file with openssl(cbc)!!!"
      openssl enc -aes-256-cbc -pbkdf2 -in $file -out [$file].enc

  elif [ $choice -eq 3 ]
  then
      echo -n "Ecryption of file $file with openssl(ecb)!!!"
      openssl enc -aes-256-ecb -pbkdf2 -in $file -out [$file].enc

  elif [ $choice -eq 2 ]
  then
      echo -n "Decryption of file $file with EBC(2) and CBC(1)!!!"
      read ch

      while [ $ch -ne 1 ] && [ $ch -ne 2 ];
      do
         echo -n "User please enter your choice:"
         read ch
      done

      if [ $ch -eq 1 ]
      then
          echo -n "Decrypt the encrypted file $file with cbc"
          openssl enc -aes-256-cbc -in $file2 -pbkdf2 -d -out [$file2].txt

      elif [ $ch -eq 2 ]
      then
          echo -n "Decrypt the encrypted file $file with ecb"
          openssl enc -aes-256-ecb -in $file2 -pbkdf2 -d -out [$file2].txt

      fi
  fi

}

cryptograph file
