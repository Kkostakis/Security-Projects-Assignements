#!/bin/bash
# 3rd Exercise made by Kkostakis

echo "User please enter your main password:" # User enters a password as input
read keypassword

echo -n "User please enter your choice:" # User enters his/her choice whether he/she wants to have his password encrypted and decrypted with md5(salting or not salting)
read choice

while [ $choice -ne 1 ] && [ $choice -ne 2 ] ; # check with while...do-done to ensure that the user will enter only choices(1 or 2)
do
  echo "User please enter your choice whether you want to encrypt with salting or without salting in md5:"
  read choice
done

if [ $choice -eq 1 ] # 1st Choice encrypts and decrypts password(that the user has entered as input) with md5 without salt
then
    echo "The main password is:$keypassword"
    keypassword=$(echo -n "$keypassword" | md5sum | cut -d' ' -f1)

    echo ""

    echo -n "This is the main password with MD5 encryption:$keypassword"

    echo ""

    echo "$keypassword" | cut -d' ' -f1  >> /home/kali/hashes.txt

    echo -n "<<Cracking password which is hashed with MD5 hash algorithm>>"
    crackmd5=$(hashcat -m 0 -a 0 -O /home/kali/hashes.txt /home/kali/Desktop/rockyou.txt --show)

    echo ""

    echo -n "The cracked md5 password is:$crackmd5"

elif [ $choice -eq 2 ] # 2nd Choice encrypts and decrypts password(that the user has entered as input) with md5 with salt
then

    echo -n "This is the main password with MD5 encryption"
    keypassword=$(openssl passwd -1 $keypassword)

    echo ""
    echo -n "This is the main password with MD5 encryption:$keypassword"

    echo ""
    echo -n "<<Cracking password which is hashed with MD5 hash algorithm and with salting>>"

    echo ""
    echo "$keypassword" >> /home/kali/hashes1.txt

    echo ""

    cracksaltedmd5=$(john --salts=[-]COUNT[:100] /home/kali/hashes1.txt)
    echo -n "The cracked md5(salting) password is:$cracksaltedmd5"
fi
